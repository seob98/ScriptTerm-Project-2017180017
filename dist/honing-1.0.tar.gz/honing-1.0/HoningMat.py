class HoningMat:
    def __init__(self, name, icon, yDayAvgPrice, recentPrice, currentMinPrice):
        self.Name = name
        self.Icon = icon
        self.YDayAvgPrice = yDayAvgPrice            #전날 거래가
        self.RecentPrice = recentPrice              #최근 거래가
        self.CurrentMinPrice = currentMinPrice      #현재 최저가


